using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{

    public Animator DialogueAnimator;
    private bool dialogueAnimatorIsOpen = false;
    public Animator ChoicesAnimator;
    private bool choicesAnimatorIsOpen = false;

    [SerializeField] TMP_Text NameText;
    [SerializeField] TMP_Text SentenceText;
    [SerializeField] TMP_Text DialogueOptionOne;
    [SerializeField] TMP_Text DialogueOptionTwo;
    [SerializeField] TMP_Text DialogueOptionThree;

    private TMP_Text[] optionArray;

    private bool isActive = false;
    private Dialogue currentDialogue;
    private int index = 0;

    private void Start()
    {
        optionArray = new TMP_Text[] { DialogueOptionOne, DialogueOptionTwo, DialogueOptionThree};
    }

    private void Update()
    {

        if (!isActive) { return; }

        if (Input.GetButtonDown("Interact"))
        {
            CloseMenus();
            if (currentDialogue.nextDialogue.Count == 0)
            {
                EndDialogue();
            }
            else
            {
                NextDialogue();
            }
        }

        if (Input.GetButtonDown("Menus_Right"))
        {
            index = (index + 1) % currentDialogue.nextDialogue.Count;
            ShowSelection();
        }
        else if (Input.GetButtonDown("Menus_Left"))
        {
            index = (index - 1) % currentDialogue.nextDialogue.Count;
            ShowSelection();
        }

    }

    public void StartDialogue(Dialogue dialogue)
    {
        currentDialogue = dialogue;
        Time.timeScale = 0f;

        DisplayDialogue();
        isActive = true;
    }

    private void DisplayDialogue()
    {
        NameText.text = currentDialogue.name;
        SentenceText.text = currentDialogue.sentence;

        DialogueAnimator.SetBool("IsOpen", dialogueAnimatorIsOpen = true);

        if (currentDialogue.nextDialogue.Count > 1)
        {
            DialogueOptionOne.text = currentDialogue.nextDialogue[0].sentence;
            DialogueOptionTwo.text = currentDialogue.nextDialogue[1].sentence;
            DialogueOptionThree.text = currentDialogue.nextDialogue[2].sentence;

            ChoicesAnimator.SetBool("IsOpen", choicesAnimatorIsOpen = true);
        }

    }

    private void NextDialogue()
    {
        currentDialogue = currentDialogue.nextDialogue[index];
        index = 0;
        DisplayDialogue();
    }

    private void EndDialogue()
    {
        NameText.text = "";
        SentenceText.text = "";
        DialogueOptionOne.text = "";
        DialogueOptionTwo.text = "";
        DialogueOptionThree.text = "";

        CloseMenus();

        Time.timeScale = 1f;
        isActive = false;
    }

    private void CloseMenus()
    {
        DialogueAnimator.SetBool("IsOpen", dialogueAnimatorIsOpen = false);
        ChoicesAnimator.SetBool("IsOpen", choicesAnimatorIsOpen = false);
    }

    private void ShowSelection()
    {
        for (int i = 0; i < optionArray.Length; i++)
        {
            if (i == index)
            {
                optionArray[i].fontStyle = FontStyles.Bold;
            }
            else
            {
                optionArray[i].fontStyle = FontStyles.Normal;
            }
        }
    }


}


/*
 * 
 * 
 * Dialogue currentDialogue = Dialogue;
        do
        {
            Debug.Log(currentDialogue.name + ": " + currentDialogue.sentence);
            currentDialogue = currentDialogue.getNextDialogue()[0];
        } while (currentDialogue.getNextDialogue().Count > 0);
        Debug.Log(currentDialogue.name + ": " + currentDialogue.sentence);
 * 
 * 
 */