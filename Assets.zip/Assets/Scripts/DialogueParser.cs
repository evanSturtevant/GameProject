using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text.RegularExpressions;
using System.IO;
using System;

public class DialogueParser
{
    string dialogueFile;
    Dialogue[] dialogueObjects;
    string[] lines;
    int[][] pointers;

    public DialogueParser(string dialogueFile)
    {
        this.dialogueFile = dialogueFile;
        lines = File.ReadAllLines(dialogueFile);
        dialogueObjects = new Dialogue[lines.Length];
        pointers = new int[lines.Length][];

        ParseLines();

        LinkDialogue();
    }

    //Parse through the dialogue file
    //Create Dialogue Objects per each said line
    //Populate pointer array 
    private void ParseLines()
    {
        string name, sentence;
        int index = 0;
        foreach (string line in lines){
            string[] tokens = line.Split(':');
            name = Regex.Match(tokens[0], @"\w+").ToString();
            sentence = tokens[1];
            dialogueObjects[index] = new Dialogue(name, sentence);

            pointers[index] = new int[tokens.Length - 2]; //Subtracting out the name and sentence

            for( int i = 2, j=0; i < tokens.Length; i++, j++)
            {
                pointers[index][j] = Int32.Parse(tokens[i]) - 1;
            }
            index++;

        }
    }

    private void LinkDialogue()
    {
        for (int i = 0; i < dialogueObjects.Length; i++)
        {
            Dialogue currentDialogue = dialogueObjects[i];

            foreach (int index in pointers[i])
            {
                currentDialogue.AddDialogue(dialogueObjects[index]);
            }
        }
    }

    public Dialogue getDialogue()
    {
        return dialogueObjects[0];
    }
}
