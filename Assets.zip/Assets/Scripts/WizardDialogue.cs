using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WizardDialogue : MonoBehaviour
{
    private DialogueManager DialogueManager;
    private DialogueParser DialogueParser;
    [SerializeField] string dialogueFile;

    public Dialogue Dialogue;
    private bool playerIsClose = false;
    private bool dialogueSaid = false;

    private void Awake()
    {
        DialogueManager = FindObjectOfType<DialogueManager>();
        DialogueParser = new DialogueParser(dialogueFile);
        Dialogue = DialogueParser.getDialogue();
    }

    public void TriggerDialogue()
    {
        Debug.Log("TEST: " + Dialogue.name);
        DialogueManager.StartDialogue(Dialogue);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            playerIsClose = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            playerIsClose = false;
        }
    }

    private void Update()
    {
        if (dialogueSaid) { return; }
        
        if (Input.GetButtonDown("Interact") && playerIsClose)
        {
            dialogueSaid = true;
            Invoke("TriggerDialogue", 0.5f);
        }
    }
}
