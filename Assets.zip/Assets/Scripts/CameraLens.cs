using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraLens : MonoBehaviour
{
    [SerializeField] Camera mainCamera;
    public float cameraDelta;
    public int lensNumber;

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.layer != LayerMask.NameToLayer("Player"))
        {
            return;
        }

        if (lensNumber == 0)
        {
            mainCamera.isCentered = false;
        }
        mainCamera.cameraDelta = this.cameraDelta;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.layer != LayerMask.NameToLayer("Player"))
        {
            return;
        }
        
        if (lensNumber == 0)
        {
            mainCamera.isCentered = true;
        }
        else {
            mainCamera.cameraDelta = mainCamera.lenses[lensNumber - 1];
        }

    }
}
