using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquishEnemyHitbox : MonoBehaviour
{
    [SerializeField] GameObject parentObject;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        GameObject other = collision.collider.gameObject;

        if (other.layer == LayerMask.NameToLayer("Player"))
        {
            Invoke("Defeated", 0.05f);
        }
    }

    private void Defeated()
    {
        Destroy(parentObject);
    }
}
