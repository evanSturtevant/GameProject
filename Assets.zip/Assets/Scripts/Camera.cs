using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    [SerializeField] float CLOSE_CAMERA_DELTA = 0.005f;
    [SerializeField] float MEDIUM_CAMERA_DELTA = 0.01f;
    [SerializeField] float WIDE_CAMERA_DELTA = 0.08f;

    public float[] lenses;
    
    [SerializeField] GameObject player;
    [SerializeField] CameraLens closeLens;
    [SerializeField] CameraLens mediumLens;
    [SerializeField] CameraLens wideLens;


    public float cameraDelta = 0.001f;
    public bool isCentered = true;

    public float cameraVelocity;


    private void Start()
    {
        lenses = new float[] { CLOSE_CAMERA_DELTA, MEDIUM_CAMERA_DELTA, WIDE_CAMERA_DELTA };


        closeLens.lensNumber = 0;
        closeLens.cameraDelta = CLOSE_CAMERA_DELTA;

        mediumLens.lensNumber = 1;
        mediumLens.cameraDelta = MEDIUM_CAMERA_DELTA;

        wideLens.lensNumber = 1;
        wideLens.cameraDelta = WIDE_CAMERA_DELTA;

        cameraVelocity = 2;

        CenterCamera(-10, -10);
    }

    void Update()
    {
        cameraVelocity = cameraDelta;

        if (isCentered)
        {
            cameraVelocity = 0;
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
        } else
        {
            CenterCamera(player.transform.position.x, player.transform.position.y);
        }


    }

    public float GetAngleTo(float x, float y)
    {

        float diffX = x - transform.position.x;
        float diffY = y - transform.position.y;

        return (float)Mathf.Atan(diffY / diffX);
    }

    public void CenterCamera(float x, float y)
    {

        //gameObject.transform.position = Vector2.MoveTowards(gameObject.transform.position, player.transform.position, cameraDelta);
        //gameObject.transform.position =new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, -10);

        float theta = GetAngleTo(x, y);

        float velocityX = cameraVelocity * Mathf.Cos(theta);
        float velocityY = cameraVelocity * Mathf.Sin(theta);

        if (x < transform.position.x)
        {
            velocityX *= -1;
            velocityY *= -1;
        }

        GetComponent<Rigidbody2D>().velocity = new Vector2(velocityX, velocityY);
    }
}
