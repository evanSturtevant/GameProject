using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Void : MonoBehaviour
{
    // Start is called before the first frame update


    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            Debug.Log("Out of Bounds!");
            //other.gameObject.transform.position = new Vector2(-1.5f, 3.5f);
            other.GetComponent<Player>().Kill();
        }
        
    }
}
