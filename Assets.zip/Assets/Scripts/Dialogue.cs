using System.Collections;
using System.Collections.Generic;

public class Dialogue 
{
    public string name;
    public string sentence;
    public List<Dialogue> nextDialogue;

    public Dialogue(string name, string sentence)
    {
        this.name = name;
        this.sentence = sentence;
        nextDialogue = new List<Dialogue>();
    }

    public void AddDialogue(Dialogue d)
    {
        nextDialogue.Add(d);
    }

    public List<Dialogue> getNextDialogue()
    {
        return nextDialogue;
    }



    
}
