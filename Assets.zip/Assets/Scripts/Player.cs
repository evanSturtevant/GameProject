using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    
    [SerializeField] float MOVE_FACTOR = 5f; //Constant which determins move speed
    [SerializeField] int MAX_JUMPS = 2;
    [SerializeField] float JUMP_VELOCITY = 12f;
    [SerializeField] float DASH_VELOCITY_Y = 4f;
    [SerializeField] float DASH_VELOCITY_X = 8f;
    [SerializeField] float DASH_TIME = 0.2f;
    [SerializeField] Sprite[] SPRITE_ARRAY;
    
    //Indexes of sprite names in SPRITE_ARRAY
    enum spriteIndex
    {
        Player_Closed,
        Player_Open,
        Player_Open_Falling
    }

    Rigidbody2D rb;
    SpriteRenderer sr;
    int numJumps;
    float playerMovement;
    bool isDashAvailable = true;
    bool isDashActive = false;
    bool onGround = true;
    bool facingRight = true;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>() as Rigidbody2D;
        sr = GetComponent<SpriteRenderer>() as SpriteRenderer;
        numJumps = MAX_JUMPS;
    }

    // Update is called once per frame
    void Update()
    {
        playerMovement = Input.GetAxis("Horizontal") * MOVE_FACTOR;
        if (playerMovement > 0)
        {
            facingRight = true;
        }
        else if (playerMovement < 0)
        {
            facingRight = false;
        }
        sr.flipX = !facingRight;

        if (Input.GetButtonDown("Jump") && numJumps > 0)
        {
            numJumps--;
            Jump();
        }

        if (Input.GetButtonDown("Dash") && isDashAvailable)
        {
            //isDashAvailable = false;
            Dash();
        }

        UpdateSprite();

    }

    private void FixedUpdate()
    {
        float yVelocity = rb.velocity.y;
        if (isDashActive)
        {
            playerMovement += DASH_VELOCITY_X;
        }
        GetComponent<Rigidbody2D>().velocity = (new Vector2(playerMovement, yVelocity));
    }

    private void Jump()
    {
        //rb.AddForce(new Vector2(0, JUMP_VELOCITY), ForceMode2D.Impulse);
        rb.velocity = new Vector2(rb.velocity.x, JUMP_VELOCITY);
    }
    private void Dash()
    {
        if (facingRight)
        {
            DASH_VELOCITY_X = Mathf.Abs(DASH_VELOCITY_X);
        }
        else
        {
            DASH_VELOCITY_X = Mathf.Abs(DASH_VELOCITY_X) * -1;
        }

        isDashActive = true;
        isDashAvailable = false;
        GetComponent<Rigidbody2D>().velocity = (new Vector2(rb.velocity.x, DASH_VELOCITY_Y));
        //rb.AddForce(new Vector2(0, DASH_VELOCITY_Y), ForceMode2D.Impulse);

        Invoke("EndDash", DASH_TIME);
    }
    private void EndDash()
    {
        isDashActive = false;
        Invoke("DashReset", DASH_TIME);

    }
    private void DashReset()
    {
        if (onGround)
        {
            isDashActive = false;
            isDashAvailable = true;
        }
    }
    public void Kill()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    private void UpdateSprite()
    {
        if (rb.velocity.y < 0)
        {
            sr.sprite = SPRITE_ARRAY[(int)spriteIndex.Player_Open_Falling];
        } else
        {
            sr.sprite = SPRITE_ARRAY[(int)spriteIndex.Player_Closed];
        }
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Player hits the ground
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Ground"))
        {
            onGround = true;
            numJumps = MAX_JUMPS;

            Invoke("DashReset", DASH_TIME);
        }
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Enemy"))
        {
            numJumps = MAX_JUMPS;

            Invoke("DashReset", DASH_TIME);
        }

    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Ground"))
        {
            onGround = false;
        }
    }

    //private void OnTriggerExit2D(Collider2D collision)
    //{
    //    if (collision.gameObject.layer == LayerMask.NameToLayer("Camera"))
    //    {
    //        Debug.Log("Calling Camera");
    //        gameObject.GetComponent<Camera>().CenterCamera();
    //    }
    //}
}

