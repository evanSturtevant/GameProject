using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquishEnemy : MonoBehaviour
{
    Rigidbody2D rb;
    SpriteRenderer sr;
    [SerializeField] float speed = 2;



    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>() as SpriteRenderer;

        rb.velocity = new Vector2(speed * -1, 0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        if (System.Math.Abs(rb.velocity.x) < 2)
        {
            speed *= -1;
            rb.velocity = new Vector2 (speed, rb.velocity.y);

            sr.flipX = speed > 0;

        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        GameObject other = collision.collider.gameObject;

        if (other.layer != LayerMask.NameToLayer("Player")) { return; }

        if (collision.relativeVelocity.y < 0 &&
            System.Math.Abs(collision.relativeVelocity.y) >= collision.relativeVelocity.x)
        {
            Destroy(this);
        } else
        {
            other.GetComponent<Player>().Kill();
        }
    }

}
